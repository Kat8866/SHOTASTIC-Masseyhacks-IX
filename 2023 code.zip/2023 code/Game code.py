#game code
from pygame import *
from random import *

width,height = 800,600
screen = display.set_mode((width, height))
RED = (255, 0, 0)
GREY = (127, 127, 127)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
WHITE=(255,255,255)

def drawScene(screen, g, bull, targ):
##    screen.blit(screenBackground, (0, 0))
    screen.fill(0)
    screen.blit(goodship, (30, g[1]-20))
    for t in targ:
        screen.blit(badship, (t[0], t[1]))
    for b in bull:  # b is 1D list
        brect = Rect(b[0], b[1], 10, 10)
        draw.ellipse(screen, RED, brect)
        draw.ellipse(screen, GREEN, brect, 2)
    display.flip()
    
def moveBullets(bull):
    for b in bull:  # b is a list (1D)
        b[0] += b[2]  # moving horizantally (run)
##        b[1] += b[3]  # moving vertically (rise)

def checkHits(bull, targ):
    for b in bull:
        brect = Rect(b[0], b[1], 10, 10)
        for t in targ:
            if brect.colliderect(Rect(t[0], t[1], 40, 40)):
                targ.remove(t)
                bull.remove(b)

class newLevel():
##    def loadScreen(screen):
##        loadScreen = screen.subsurface(0, 0, 800, 600)
##        loadScreen.fil  98yvl(0)
##        font.init()
##        comfont = font.SysFont("Comic Sans", 25)
##        message = comfont.render("Congrats. You passed.\nLoading next level...", True, (255, 255, 255))
##        loadScreen.blit(message, (350, 290))
##        draw.rect(screen, RED, (100, 200, 10, 320))
##        buttonRect = Rect(350, 200, 100, 50)
##        draw.rect(screen, (255, 255, 255), buttonRect, 2, 4)
##        go = comfont.render("GO", True, (255, 255, 255))
##        loadScreen.blit(go, (390, 225))
##        if mb[1]:
##            if buttonRect.collidepoint(mx, my):
##                draw.rect(screen, (255, 0, 0), buttonRect, 2, 4)
##                return True
##        return False
##

##def inbetween():
##    screen(WHITE)
    
        
    def reset(bullets, targets):
        bullets = []
        targets = [[randint(400, 750), randint(100, 500)] for i in range(12)]
        return bullets, targets
        

bullets = []  # [[100, 75, 2, 0], [115, 222, 1, 0], [70, 400, 3, 0]]
targets = [[randint(400, 750), randint(100, 500)] for i in range(6)]

running = True

myClock = time.Clock()
screenBackground = image.load("images/spaceBG.png")
goodship = image.load("images/goodship.png")  # you
goodship = transform.scale(goodship, (40, 40))
badship = image.load("images/badship.png")
badship = transform.scale(badship, (40, 40))

while running:
    for evt in event.get():
        if evt.type == QUIT:
            running = False
        if evt.type == MOUSEBUTTONDOWN:
            if evt.button == 1:
                bullets.append([50, guy[1]-20, 2, 0])

    guy = mouse.get_pos()
                       
    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()

    drawScene(screen, guy, bullets, targets)
    moveBullets(bullets)
    checkHits(bullets, targets)
    if len(targets) == 0:
##        inbetween(screen)
##        exitScreen = False
##        exitScreen = newLevel.loadScreen(screen)
##        newLevel.loadScreen(screen)
##        if exitScreen == True:
        bullets, targets = newLevel.reset(bullets, targets)
      
    myClock.tick(250)
    display.flip()
            
quit()

